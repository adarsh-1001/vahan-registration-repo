import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# Page configuration with dark theme
st.set_page_config(
    page_title="VAHAN Vehicle Registration Dashboard",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for dark theme
st.markdown("""
<style>
    .metric-card {
        background: linear-gradient(145deg, #2e2e2e, #404040);
        padding: 1.5rem;
        border-radius: 15px;
        margin: 0.5rem 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        text-align: center;
    }
    .metric-value {
        font-size: 2.5rem;
        font-weight: bold;
        color: #00ff88;
    }
    .metric-label {
        font-size: 1rem;
        color: #cccccc;
        margin-bottom: 0.5rem;
    }
    .growth-positive {
        color: #00ff88 !important;
    }
    .growth-negative {
        color: #ff4444 !important;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_sample_data():
    """Load sample VAHAN data for demonstration."""
    try:
        df = pd.read_csv('sample_vahan_data.csv')
        df['month'] = pd.to_datetime(df['month'])
        return df
    except:
        # Generate sample data
        dates = pd.date_range('2024-01-01', '2024-03-01', freq='M')
        categories = ['TWO WHEELER', 'FOUR WHEELER', 'THREE WHEELER']
        manufacturers = ['Hero MotoCorp', 'Honda', 'TVS', 'Maruti Suzuki', 'Hyundai', 'Bajaj']
        states = ['Maharashtra', 'Uttar Pradesh', 'Tamil Nadu', 'Karnataka']
        
        data = []
        for date in dates:
            for state in states:
                for category in categories:
                    for mfg in np.random.choice(manufacturers, 2):
                        registrations = np.random.randint(1000, 50000)
                        data.append({
                            'month': date,
                            'state_name': state,
                            'veh_cat': category,
                            'maker': mfg,
                            'fuel_type': np.random.choice(['PETROL', 'DIESEL', 'ELECTRIC']),
                            'registrations': registrations
                        })
        
        return pd.DataFrame(data)

def format_number(value):
    """Format numbers with appropriate suffixes."""
    if value >= 1e9:
        return f"{value/1e9:.2f}B"
    elif value >= 1e6:
        return f"{value/1e6:.2f}M"
    elif value >= 1e3:
        return f"{value/1e3:.2f}K"
    else:
        return f"{value:,.0f}"

def calculate_growth_metrics(df):
    """Calculate growth metrics safely."""
    if df.empty or 'month' not in df.columns:
        return {
            'yoy_growth': pd.DataFrame(),
            'monthly_totals': pd.DataFrame()
        }
    
    # Ensure datetime
    df['month'] = pd.to_datetime(df['month'])
    df['year'] = df['month'].dt.year
    df['month_num'] = df['month'].dt.month
    
    # Monthly totals
    monthly_totals = df.groupby('month')['registrations'].sum().reset_index()
    monthly_totals = monthly_totals.sort_values('month')
    
    # YoY growth by year
    yearly_totals = df.groupby('year')['registrations'].sum().reset_index()
    yearly_totals['yoy_growth'] = yearly_totals['registrations'].pct_change() * 100
    
    return {
        'yoy_growth': yearly_totals,
        'monthly_totals': monthly_totals
    }

def create_growth_chart(growth_data):
    """Create a simple growth chart."""
    if growth_data['monthly_totals'].empty:
        st.info("No growth data available")
        return
    
    df = growth_data['monthly_totals']
    
    fig = px.line(df, x='month', y='registrations', 
                  title='Monthly Vehicle Registrations Trend',
                  color_discrete_sequence=['#00ff88'])
    
    fig.update_layout(
        plot_bgcolor='#1e1e1e',
        paper_bgcolor='#2d2d2d',
        font=dict(color='#ffffff'),
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

def create_category_chart(df):
    """Create category breakdown chart."""
    if df.empty or 'veh_cat' not in df.columns:
        st.info("No category data available")
        return
    
    category_totals = df.groupby('veh_cat')['registrations'].sum().reset_index()
    
    fig = px.pie(category_totals, values='registrations', names='veh_cat',
                 title='Vehicle Category Distribution',
                 color_discrete_sequence=['#00ff88', '#ff6b6b', '#4ecdc4', '#45b7d1'])
    
    fig.update_layout(
        plot_bgcolor='#1e1e1e',
        paper_bgcolor='#2d2d2d',
        font=dict(color='#ffffff'),
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

def create_manufacturer_chart(df):
    """Create manufacturer chart."""
    if df.empty or 'maker' not in df.columns:
        st.info("No manufacturer data available")
        return
    
    mfg_totals = df.groupby('maker')['registrations'].sum().reset_index()
    mfg_totals = mfg_totals.nlargest(10, 'registrations')
    
    fig = px.bar(mfg_totals, x='registrations', y='maker', orientation='h',
                 title='Top 10 Manufacturers by Registrations',
                 color='registrations', color_continuous_scale='Viridis')
    
    fig.update_layout(
        plot_bgcolor='#1e1e1e',
        paper_bgcolor='#2d2d2d',
        font=dict(color='#ffffff'),
        height=500,
        yaxis={'categoryorder': 'total ascending'}
    )
    
    st.plotly_chart(fig, use_container_width=True)

def main():
    # Header
    st.markdown('<h1 style="text-align: center; color: #ffffff; font-size: 3rem;">🚗 VAHAN Vehicle Registration Dashboard</h1>', unsafe_allow_html=True)
    st.markdown('<p style="text-align: center; color: #888; font-size: 1.2rem;">Professional Investor-Focused Analysis</p>', unsafe_allow_html=True)
    
    # Load data
    with st.spinner("Loading VAHAN data..."):
        df = load_sample_data()
    
    if df.empty:
        st.error("No data available")
        return
    
    # Sidebar filters
    st.sidebar.markdown("### 📊 Dashboard Controls")
    
    # Auto-refresh button
    if st.sidebar.button("🔄 Refresh Data", type="primary"):
        st.cache_data.clear()
        st.rerun()
    
    # Date range
    if 'month' in df.columns:
        min_date = df['month'].min().date()
        max_date = df['month'].max().date()
        
        st.sidebar.markdown("#### 📅 Date Range")
        start_date = st.sidebar.date_input("Start Date", value=min_date, min_value=min_date, max_value=max_date)
        end_date = st.sidebar.date_input("End Date", value=max_date, min_value=min_date, max_value=max_date)
        
        # Filter by date
        df_filtered = df[(df['month'].dt.date >= start_date) & (df['month'].dt.date <= end_date)]
    else:
        df_filtered = df
    
    # Category filter
    if 'veh_cat' in df_filtered.columns:
        st.sidebar.markdown("#### 🚙 Vehicle Category")
        categories = df_filtered['veh_cat'].unique()
        selected_categories = st.sidebar.multiselect("Select Categories", options=categories, default=categories)
        df_filtered = df_filtered[df_filtered['veh_cat'].isin(selected_categories)]
    
    # Manufacturer filter
    if 'maker' in df_filtered.columns:
        st.sidebar.markdown("#### 🏭 Manufacturer")
        manufacturers = sorted(df_filtered['maker'].unique())
        selected_manufacturers = st.sidebar.multiselect("Select Manufacturers", options=manufacturers, default=manufacturers[:5])
        if selected_manufacturers:
            df_filtered = df_filtered[df_filtered['maker'].isin(selected_manufacturers)]
    
    if df_filtered.empty:
        st.warning("No data available for selected filters")
        return
    
    # KPI Cards
    total_registrations = df_filtered['registrations'].sum()
    unique_manufacturers = df_filtered['maker'].nunique() if 'maker' in df_filtered.columns else 0
    unique_states = df_filtered['state_name'].nunique() if 'state_name' in df_filtered.columns else 0
    
    # Calculate YoY growth if possible
    growth_data = calculate_growth_metrics(df_filtered)
    yoy_growth = 0
    if not growth_data['yoy_growth'].empty and len(growth_data['yoy_growth']) > 1:
        latest_yoy = growth_data['yoy_growth'].iloc[-1]['yoy_growth']
        if not pd.isna(latest_yoy):
            yoy_growth = latest_yoy
    
    # Display KPI cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">TOTAL REGISTRATIONS</div>
            <div class="metric-value">{format_number(total_registrations)}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        growth_color = "growth-positive" if yoy_growth >= 0 else "growth-negative"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">YoY GROWTH</div>
            <div class="metric-value {growth_color}">{yoy_growth:+.1f}%</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">ACTIVE MANUFACTURERS</div>
            <div class="metric-value">{unique_manufacturers}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">STATES COVERED</div>
            <div class="metric-value">{unique_states}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Charts sections
    st.markdown("## 📈 Growth Analysis")
    create_growth_chart(growth_data)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🚗 Vehicle Category Analysis")
        create_category_chart(df_filtered)
    
    with col2:
        st.markdown("### 🏭 Manufacturer Performance")
        create_manufacturer_chart(df_filtered)
    
    # Investor Insights
    st.markdown("## 💼 Investment Insights")
    
    # Calculate key insights
    if not df_filtered.empty:
        insights = []
        
        if 'veh_cat' in df_filtered.columns:
            dominant_category = df_filtered.groupby('veh_cat')['registrations'].sum().idxmax()
            category_share = (df_filtered.groupby('veh_cat')['registrations'].sum().max() / 
                            df_filtered['registrations'].sum() * 100)
            insights.append(f"🚗 **Dominant Category**: {dominant_category} ({category_share:.1f}% market share)")
        
        if 'maker' in df_filtered.columns:
            top_manufacturer = df_filtered.groupby('maker')['registrations'].sum().idxmax()
            insights.append(f"🏆 **Market Leader**: {top_manufacturer}")
        
        if 'state_name' in df_filtered.columns:
            top_state = df_filtered.groupby('state_name')['registrations'].sum().idxmax()
            state_share = (df_filtered.groupby('state_name')['registrations'].sum().max() / 
                          df_filtered['registrations'].sum() * 100)
            insights.append(f"🗺️ **Top State**: {top_state} ({state_share:.1f}% of registrations)")
        
        if yoy_growth > 10:
            insights.append("🚀 **Strong Growth**: YoY growth exceeds 10%, indicating robust market expansion")
        elif yoy_growth > 5:
            insights.append("📈 **Moderate Growth**: YoY growth between 5-10%, showing steady market development")
        elif yoy_growth > 0:
            insights.append("📊 **Slow Growth**: YoY growth below 5%, market showing signs of maturity")
        else:
            insights.append("📉 **Market Contraction**: Negative YoY growth, potential market challenges")
        
        for insight in insights:
            st.markdown(f"<div style='background: linear-gradient(145deg, #1e3a5f, #2d5aa0); padding: 1rem; border-radius: 10px; margin: 0.5rem 0; border-left: 4px solid #00ff88; color: white;'>{insight}</div>", unsafe_allow_html=True)
    
    # Export functionality
    st.markdown("## 📥 Data Export")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📊 Export Filtered Data", type="primary"):
            csv = df_filtered.to_csv(index=False)
            st.download_button(
                label="⬇️ Download CSV",
                data=csv,
                file_name=f"vahan_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("📈 Export Growth Data", type="primary") and not growth_data['yoy_growth'].empty:
            csv = growth_data['yoy_growth'].to_csv(index=False)
            st.download_button(
                label="⬇️ Download Growth CSV",
                data=csv,
                file_name=f"vahan_growth_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; padding: 2rem;">
        <strong>Data Source:</strong> VAHAN Dashboard - Ministry of Road Transport and Highways, Government of India<br>
        <strong>Dashboard Purpose:</strong> Investor-focused analysis of vehicle registration trends<br>
        <strong>Technology Stack:</strong> Python, Streamlit, Plotly, Pandas
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()