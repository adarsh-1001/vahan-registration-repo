import pandas as pd
import numpy as np

def format_number(value):
    """Format numbers with appropriate suffixes (K, M, B)."""
    if pd.isna(value):
        return "N/A"
    
    value = float(value)
    if value >= 1e9:
        return f"{value/1e9:.2f}B"
    elif value >= 1e6:
        return f"{value/1e6:.2f}M"
    elif value >= 1e3:
        return f"{value/1e3:.2f}K"
    else:
        return f"{value:,.0f}"

def format_percentage(value):
    """Format percentage values."""
    if pd.isna(value):
        return "N/A"
    return f"{value:.2f}%"

def calculate_growth_rate(current, previous):
    """Calculate growth rate between two periods."""
    if pd.isna(current) or pd.isna(previous) or previous == 0:
        return np.nan
    return ((current - previous) / previous) * 100

def create_date_range(start_date, end_date, freq='M'):
    """Create date range with specified frequency."""
    return pd.date_range(start=start_date, end=end_date, freq=freq)

def clean_text_column(series):
    """Clean text column by removing extra spaces and standardizing."""
    return series.str.strip().str.upper().fillna('UNKNOWN')

def validate_numeric_column(series):
    """Validate and clean numeric column."""
    numeric_series = pd.to_numeric(series, errors='coerce')
    return numeric_series.fillna(0)

def calculate_market_share(values):
    """Calculate market share percentages."""
    total = values.sum()
    if total == 0:
        return pd.Series([0] * len(values), index=values.index)
    return (values / total) * 100

def get_top_n_categories(df, category_col, value_col, n=10):
    """Get top N categories by value."""
    return df.groupby(category_col)[value_col].sum().nlargest(n).index.tolist()

def calculate_compound_growth_rate(start_value, end_value, periods):
    """Calculate Compound Annual Growth Rate (CAGR)."""
    if start_value <= 0 or end_value <= 0 or periods <= 0:
        return np.nan
    return ((end_value / start_value) ** (1/periods) - 1) * 100

def detect_seasonality(time_series_data, date_col, value_col):
    """Detect seasonal patterns in time series data."""
    df = time_series_data.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df['month'] = df[date_col].dt.month
    
    monthly_avg = df.groupby('month')[value_col].mean()
    overall_avg = df[value_col].mean()
    
    # Calculate seasonal index
    seasonal_index = (monthly_avg / overall_avg) * 100
    return seasonal_index

def identify_outliers(series, method='iqr', threshold=1.5):
    """Identify outliers in a numeric series."""
    if method == 'iqr':
        Q1 = series.quantile(0.25)
        Q3 = series.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        return series[(series < lower_bound) | (series > upper_bound)]
    
    elif method == 'zscore':
        z_scores = np.abs((series - series.mean()) / series.std())
        return series[z_scores > threshold]
    
    return pd.Series(dtype=float)

def calculate_moving_average(series, window=3):
    """Calculate moving average for smoothing time series."""
    return series.rolling(window=window, center=True).mean()

def format_currency(value, currency='₹'):
    """Format currency values."""
    if pd.isna(value):
        return "N/A"
    
    formatted_number = format_number(value)
    return f"{currency} {formatted_number}"

def get_period_labels(start_date, end_date, freq='M'):
    """Generate period labels for time series."""
    dates = pd.date_range(start=start_date, end=end_date, freq=freq)
    
    if freq == 'M':
        return [f"{date.strftime('%b %Y')}" for date in dates]
    elif freq == 'Q':
        return [f"Q{date.quarter} {date.year}" for date in dates]
    elif freq == 'Y':
        return [f"{date.year}" for date in dates]
    else:
        return [date.strftime('%Y-%m-%d') for date in dates]

def calculate_volatility(series):
    """Calculate volatility (standard deviation) of a series."""
    if len(series) < 2:
        return np.nan
    return series.std()

def normalize_data(series, method='min-max'):
    """Normalize data using specified method."""
    if method == 'min-max':
        return (series - series.min()) / (series.max() - series.min())
    elif method == 'z-score':
        return (series - series.mean()) / series.std()
    return series

def aggregate_by_period(df, date_col, value_col, period='M'):
    """Aggregate data by time period."""
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    
    return df.groupby(pd.Grouper(key=date_col, freq=period))[value_col].sum().reset_index()
