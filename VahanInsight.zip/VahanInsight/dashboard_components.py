import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from utils import format_number, format_percentage

class DashboardComponents:
    def __init__(self):
        # Dark theme color palette
        self.color_palette = [
            '#00ff88', '#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24',
            '#f0932b', '#eb4d4b', '#6c5ce7', '#a29bfe', '#fd79a8'
        ]
        # Dark theme layout settings
        self.plot_bgcolor = '#1e1e1e'
        self.paper_bgcolor = '#2d2d2d'
        self.font_color = '#ffffff'
        self.grid_color = '#404040'
    
    def create_yoy_growth_chart(self, yoy_data):
        """Create Year-over-Year growth chart."""
        if yoy_data.empty:
            st.info("No YoY data available")
            return
        
        fig = go.Figure()
        
        # Add registration bars
        fig.add_trace(go.Bar(
            x=yoy_data['year'],
            y=yoy_data['registrations'],
            name='Registrations',
            yaxis='y',
            marker_color='lightblue',
            opacity=0.7
        ))
        
        # Add growth rate line
        fig.add_trace(go.Scatter(
            x=yoy_data['year'],
            y=yoy_data['yoy_growth'],
            mode='lines+markers',
            name='YoY Growth %',
            yaxis='y2',
            line=dict(color='red', width=3),
            marker=dict(size=8)
        ))
        
        fig.update_layout(
            title=dict(
                text='Year-over-Year Growth Analysis',
                font=dict(color=self.font_color, size=18)
            ),
            xaxis_title='Year',
            yaxis=dict(
                title='Total Registrations',
                side='left',
                color=self.font_color,
                gridcolor=self.grid_color
            ),
            yaxis2=dict(
                title='Growth Rate (%)',
                side='right',
                overlaying='y',
                color=self.font_color
            ),
            plot_bgcolor=self.plot_bgcolor,
            paper_bgcolor=self.paper_bgcolor,
            font=dict(color=self.font_color),
            hovermode='x unified',
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Display key insights
        if not yoy_data['yoy_growth'].isna().all():
            latest_growth = yoy_data['yoy_growth'].iloc[-1]
            avg_growth = yoy_data['yoy_growth'].mean()
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Latest YoY Growth", format_percentage(latest_growth))
            with col2:
                st.metric("Average YoY Growth", format_percentage(avg_growth))
            with col3:
                growth_trend = "📈" if latest_growth > avg_growth else "📉"
                st.metric("Trend", f"{growth_trend} {'Above' if latest_growth > avg_growth else 'Below'} Average")
    
    def create_qoq_growth_chart(self, qoq_data):
        """Create Quarter-over-Quarter growth chart."""
        if qoq_data.empty:
            st.info("No QoQ data available")
            return
        
        # Create quarter labels
        qoq_data['quarter_label'] = qoq_data['year'].astype(str) + '-Q' + qoq_data['quarter'].astype(str)
        
        fig = go.Figure()
        
        # Add registration bars
        fig.add_trace(go.Bar(
            x=qoq_data['quarter_label'],
            y=qoq_data['registrations'],
            name='Registrations',
            yaxis='y',
            marker_color='lightgreen',
            opacity=0.7
        ))
        
        # Add growth rate line
        fig.add_trace(go.Scatter(
            x=qoq_data['quarter_label'],
            y=qoq_data['qoq_growth'],
            mode='lines+markers',
            name='QoQ Growth %',
            yaxis='y2',
            line=dict(color='orange', width=3),
            marker=dict(size=8)
        ))
        
        fig.update_layout(
            title=dict(
                text='Quarter-over-Quarter Growth Analysis',
                font=dict(color=self.font_color, size=18)
            ),
            xaxis_title='Quarter',
            xaxis=dict(color=self.font_color, gridcolor=self.grid_color),
            yaxis=dict(
                title='Total Registrations',
                side='left',
                color=self.font_color,
                gridcolor=self.grid_color
            ),
            yaxis2=dict(
                title='Growth Rate (%)',
                side='right',
                overlaying='y',
                color=self.font_color
            ),
            plot_bgcolor=self.plot_bgcolor,
            paper_bgcolor=self.paper_bgcolor,
            font=dict(color=self.font_color),
            hovermode='x unified',
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Display key insights
        if not qoq_data['qoq_growth'].isna().all():
            latest_growth = qoq_data['qoq_growth'].iloc[-1]
            avg_growth = qoq_data['qoq_growth'].mean()
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Latest QoQ Growth", format_percentage(latest_growth))
            with col2:
                st.metric("Average QoQ Growth", format_percentage(avg_growth))
            with col3:
                volatility = qoq_data['qoq_growth'].std()
                st.metric("Growth Volatility", format_percentage(volatility))
    
    def create_category_analysis_charts(self, category_data):
        """Create vehicle category analysis charts."""
        if not category_data or 'time_series' not in category_data:
            st.info("No category data available")
            return
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Time series by category
            fig = px.line(
                category_data['time_series'],
                x='month',
                y='registrations',
                color='veh_cat',
                title='Registration Trends by Vehicle Category',
                color_discrete_sequence=self.color_palette
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Category distribution pie chart
            if 'totals' in category_data:
                fig = px.pie(
                    category_data['totals'],
                    values='registrations',
                    names='veh_cat',
                    title='Market Share by Vehicle Category',
                    color_discrete_sequence=self.color_palette
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
        
        # Category performance table
        if 'totals' in category_data:
            st.subheader("Category Performance Summary")
            totals_df = category_data['totals'].copy()
            totals_df['market_share'] = (totals_df['registrations'] / totals_df['registrations'].sum() * 100).round(2)
            totals_df['registrations'] = totals_df['registrations'].apply(format_number)
            totals_df = totals_df.rename(columns={
                'veh_cat': 'Vehicle Category',
                'registrations': 'Total Registrations',
                'market_share': 'Market Share (%)'
            })
            st.dataframe(totals_df, use_container_width=True)
    
    def create_manufacturer_analysis_charts(self, manufacturer_data):
        """Create manufacturer analysis charts."""
        if not manufacturer_data or 'time_series' not in manufacturer_data:
            st.info("No manufacturer data available")
            return
        
        # Top manufacturers bar chart
        if 'totals' in manufacturer_data:
            fig = px.bar(
                manufacturer_data['totals'].head(10),
                x='registrations',
                y='maker',
                orientation='h',
                title='Top 10 Manufacturers by Total Registrations',
                color='registrations',
                color_continuous_scale='Blues'
            )
            fig.update_layout(height=500, yaxis={'categoryorder': 'total ascending'})
            st.plotly_chart(fig, use_container_width=True)
        
        # Manufacturer trends over time
        if len(manufacturer_data['time_series']) > 0:
            fig = px.line(
                manufacturer_data['time_series'],
                x='month',
                y='registrations',
                color='maker',
                title='Registration Trends - Top Manufacturers',
                color_discrete_sequence=self.color_palette
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        # Manufacturer performance metrics
        if 'totals' in manufacturer_data:
            st.subheader("Manufacturer Performance Metrics")
            metrics_df = manufacturer_data['totals'].head(5).copy()
            total_registrations = metrics_df['registrations'].sum()
            metrics_df['market_share'] = (metrics_df['registrations'] / total_registrations * 100).round(2)
            metrics_df['registrations_formatted'] = metrics_df['registrations'].apply(format_number)
            
            display_df = metrics_df[['maker', 'registrations_formatted', 'market_share']].rename(columns={
                'maker': 'Manufacturer',
                'registrations_formatted': 'Total Registrations',
                'market_share': 'Market Share (%)'
            })
            st.dataframe(display_df, use_container_width=True)
    
    def create_geographic_charts(self, geo_data):
        """Create geographic analysis charts."""
        if geo_data.empty:
            st.info("No geographic data available")
            return
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Top states bar chart
            fig = px.bar(
                geo_data.head(10),
                x='registrations',
                y='state_name',
                orientation='h',
                title='Top 10 States by Vehicle Registrations',
                color='registrations',
                color_continuous_scale='Viridis'
            )
            fig.update_layout(height=500, yaxis={'categoryorder': 'total ascending'})
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Geographic distribution metrics
            st.subheader("Geographic Concentration")
            
            total_registrations = geo_data['registrations'].sum()
            top_5_share = (geo_data.head(5)['registrations'].sum() / total_registrations * 100)
            top_10_share = (geo_data.head(10)['registrations'].sum() / total_registrations * 100)
            
            st.metric("Top 5 States Market Share", format_percentage(top_5_share))
            st.metric("Top 10 States Market Share", format_percentage(top_10_share))
            
            # Top states table
            st.subheader("State-wise Distribution")
            display_geo = geo_data.head(10).copy()
            display_geo['market_share'] = (display_geo['registrations'] / total_registrations * 100).round(2)
            display_geo['registrations'] = display_geo['registrations'].apply(format_number)
            display_geo = display_geo.rename(columns={
                'state_name': 'State',
                'registrations': 'Total Registrations',
                'market_share': 'Market Share (%)'
            })
            st.dataframe(display_geo, use_container_width=True)
    
    def display_investor_insights(self, insights):
        """Display key investor insights."""
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📊 Market Overview")
            if 'total_market_size' in insights:
                st.metric("Total Market Size", format_number(insights['total_market_size']))
            
            if 'market_leader' in insights:
                st.info(f"🏆 **Market Leader**: {insights['market_leader']}")
            
            if 'dominant_category' in insights and 'category_share' in insights:
                st.info(f"🚗 **Dominant Category**: {insights['dominant_category']} ({insights['category_share']:.1f}%)")
        
        with col2:
            st.subheader("📈 Growth Metrics")
            if 'latest_yoy_growth' in insights:
                yoy_growth = insights['latest_yoy_growth']
                st.metric("Latest YoY Growth", format_percentage(yoy_growth), 
                         delta=f"{yoy_growth:.1f}%" if not pd.isna(yoy_growth) else None)
            
            if 'latest_qoq_growth' in insights:
                qoq_growth = insights['latest_qoq_growth']
                st.metric("Latest QoQ Growth", format_percentage(qoq_growth),
                         delta=f"{qoq_growth:.1f}%" if not pd.isna(qoq_growth) else None)
        
        # Investment insights
        st.subheader("💡 Key Investment Insights")
        
        insights_text = []
        
        if 'latest_yoy_growth' in insights and not pd.isna(insights['latest_yoy_growth']):
            yoy = insights['latest_yoy_growth']
            if yoy > 10:
                insights_text.append("🚀 **Strong Growth**: YoY growth exceeds 10%, indicating robust market expansion")
            elif yoy > 5:
                insights_text.append("📈 **Moderate Growth**: YoY growth between 5-10%, showing steady market development")
            elif yoy > 0:
                insights_text.append("📊 **Slow Growth**: YoY growth below 5%, market showing signs of maturity")
            else:
                insights_text.append("📉 **Market Contraction**: Negative YoY growth, potential market challenges")
        
        if 'state_concentration' in insights:
            concentration = insights['state_concentration']
            if concentration > 30:
                insights_text.append(f"🎯 **High Geographic Concentration**: Top state accounts for {concentration:.1f}% of market")
            else:
                insights_text.append(f"🗺️ **Distributed Market**: Geographic distribution is relatively balanced")
        
        if 'category_share' in insights and 'dominant_category' in insights:
            category_share = insights['category_share']
            category = insights['dominant_category']
            if 'TWO WHEELER' in category and category_share > 60:
                insights_text.append("🛵 **Two-Wheeler Dominance**: Market heavily skewed towards two-wheelers, reflecting transportation preferences")
            elif 'FOUR WHEELER' in category and category_share > 40:
                insights_text.append("🚗 **Growing Car Market**: Four-wheelers showing strong market presence, indicating economic growth")
        
        for insight in insights_text:
            st.markdown(insight)
        
        # Risk factors
        st.subheader("⚠️ Risk Considerations")
        risk_factors = [
            "📋 **Regulatory Changes**: Government policies on vehicle emissions and electric vehicles may impact growth",
            "⛽ **Fuel Price Volatility**: Changes in fuel prices can affect vehicle demand patterns",
            "🏭 **Supply Chain Disruptions**: Global semiconductor shortage and raw material costs may impact production",
            "💰 **Economic Cycles**: Vehicle registrations are sensitive to economic conditions and consumer confidence"
        ]
        
        for risk in risk_factors:
            st.markdown(risk)
