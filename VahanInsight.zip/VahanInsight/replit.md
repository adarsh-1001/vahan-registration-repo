# VAHAN Vehicle Registration Dashboard

## Overview

This is a professional, dark-themed investor dashboard analyzing vehicle registration trends in India using live VAHAN data from the Ministry of Road Transport and Highways. Built for the Backend Developer Internship Assignment, the application features modern UI/UX, real-time data integration, comprehensive growth analysis (YoY and QoQ), and investor-focused insights through interactive visualizations. The dashboard tracks key vehicle categories (2W, 3W, 4W, Others) and provides market analysis including manufacturer performance, geographic distribution, and seasonal trends.

## Recent Changes (August 14, 2025)

### Major Architecture Updates
- **Dark Theme Implementation**: Complete redesign with professional dark color scheme
- **Enhanced Error Handling**: Robust datetime conversion and data validation
- **Fallback Data System**: Added sample CSV for offline demonstration
- **KPI Cards**: Custom HTML/CSS metric cards with gradient styling
- **Modular Refactor**: Separated concerns with improved component architecture
- **Export Functionality**: Enhanced CSV download with timestamp naming

### UI/UX Improvements
- **Professional Styling**: Custom CSS with gradient cards and modern typography
- **Responsive Design**: Optimized for desktop and mobile viewing
- **Interactive Elements**: Enhanced hover effects and visual feedback
- **Color Palette**: Investor-friendly colors with growth indicators
- **Auto-refresh**: Manual data refresh capability for live updates

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit-based web application with wide layout configuration
- **Visualization Engine**: Plotly Express and Plotly Graph Objects for interactive charts and graphs
- **Component Structure**: Modularized design with separate classes for dashboard components and data processing
- **State Management**: Streamlit's built-in caching system using `@st.cache_data` and `@st.cache_resource` decorators
- **User Interface**: Sidebar-based filtering system with expandable controls and responsive layout

### Backend Architecture
- **Data Processing Layer**: `DataProcessor` class handles all data fetching, cleaning, and transformation operations
- **Component Layer**: `DashboardComponents` class manages chart creation and visualization logic
- **Utility Layer**: Shared utilities for number formatting, growth calculations, and data validation
- **Error Handling**: Graceful fallback mechanisms with sample data generation for development/demo purposes

### Data Processing Pipeline
- **Primary Data Source**: India Data Portal VAHAN dataset via REST API
- **Fallback Mechanism**: Multiple data fetching strategies including direct CSV download and sample data generation
- **Data Cleaning**: Standardized text processing, numeric validation, and missing value handling
- **Analytics Engine**: YoY and QoQ growth calculations, market share analysis, and trend identification

### Application Structure
- **Main Application**: `app.py` orchestrates the entire dashboard flow
- **Data Layer**: `data_processor.py` handles all data operations and API interactions
- **Presentation Layer**: `dashboard_components.py` manages chart creation and visual components
- **Utility Functions**: `utils.py` provides shared formatting and calculation functions

## External Dependencies

### Data Sources
- **India Data Portal**: Primary data source for VAHAN vehicle registration data
- **API Endpoint**: `https://ckandev.indiadataportal.com/api/action/datastore_search`
- **Resource ID**: `808d2b3c-dcdd-48fc-ae6a-cc99e137ec9c`

### Core Python Libraries
- **Streamlit**: Web application framework and UI components
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computing and array operations
- **Plotly**: Interactive visualization library (Express and Graph Objects)

### Data Processing Libraries
- **Requests**: HTTP library for API calls and data fetching
- **datetime**: Date and time handling for temporal analysis
- **io**: Input/output operations for data streaming

### System Requirements
- **Python**: Version 3.7 or higher
- **Internet Connection**: Required for real-time data fetching from India Data Portal
- **Browser**: Modern web browser for Streamlit interface

### API Integration
- **REST API**: Integration with India Data Portal's datastore search API
- **Timeout Handling**: 30-second timeout for API requests
- **Rate Limiting**: Configurable data limits (50,000 records default)
- **Fallback Strategy**: Multiple endpoints and sample data generation for reliability