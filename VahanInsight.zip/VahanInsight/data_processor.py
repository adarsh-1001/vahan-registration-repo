import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import streamlit as st
import io

class DataProcessor:
    def __init__(self):
        self.vahan_data_url = "https://ckandev.indiadataportal.com/dataset/vahan-vehicle-registrations/resource/808d2b3c-dcdd-48fc-ae6a-cc99e137ec9c"
        self.api_base_url = "https://ckandev.indiadataportal.com/api/action/datastore_search"
        self.resource_id = "808d2b3c-dcdd-48fc-ae6a-cc99e137ec9c"
    
    @st.cache_data
    def load_vahan_data(_self):
        """Load VAHAN vehicle registration data from India Data Portal."""
        try:
            # Try to fetch data via API first
            params = {
                'resource_id': _self.resource_id,
                'limit': 50000  # Adjust limit based on needs
            }
            
            response = requests.get(_self.api_base_url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                if 'result' in data and 'records' in data['result']:
                    df = pd.DataFrame(data['result']['records'])
                    return _self._clean_vahan_data(df)
            
            # Fallback: Try direct CSV download approach
            try:
                # Alternative approach - try different endpoints
                csv_url = "https://ckandev.indiadataportal.com/dataset/808d2b3c-dcdd-48fc-ae6a-cc99e137ec9c/resource/808d2b3c-dcdd-48fc-ae6a-cc99e137ec9c/download"
                df = pd.read_csv(csv_url)
                return _self._clean_vahan_data(df)
            except:
                pass
            
            # Try loading sample CSV file as fallback
            try:
                df = pd.read_csv('sample_vahan_data.csv')
                st.info("📋 Using sample data file as fallback. Real-time data unavailable.")
                return _self._clean_vahan_data(df)
            except:
                pass
            
            # Generate sample realistic data structure if all fails (for demo purposes)
            return _self._generate_sample_data_structure()
            
        except Exception as e:
            st.error(f"Error loading VAHAN data: {str(e)}")
            # Return sample data structure for development/demo
            return _self._generate_sample_data_structure()
    
    def _clean_vahan_data(self, df):
        """Clean and standardize VAHAN data."""
        # Standardize column names
        column_mapping = {
            'Month': 'month',
            'month': 'month',
            'Date': 'date',
            'date': 'date',
            'State Name': 'state_name',
            'state_name': 'state_name',
            'State Code': 'state_code',
            'state_code': 'state_code',
            'RTO Name': 'rto_name',
            'rto_name': 'rto_name',
            'RTO Code': 'rto_code',
            'rto_code': 'rto_code',
            'Vehicle Category': 'veh_cat',
            'veh_cat': 'veh_cat',
            'Vehicle Class': 'veh_class',
            'veh_class': 'veh_class',
            'Maker': 'maker',
            'maker': 'maker',
            'Fuel Type': 'fuel_type',
            'fuel_type': 'fuel_type',
            'Registrations': 'registrations',
            'registrations': 'registrations',
            'count': 'registrations',
            'vehicle_count': 'registrations'
        }
        
        # Rename columns
        for old_col, new_col in column_mapping.items():
            if old_col in df.columns:
                df = df.rename(columns={old_col: new_col})
        
        # Ensure required columns exist
        required_columns = ['registrations']
        for col in required_columns:
            if col not in df.columns:
                df[col] = 1  # Default value
        
        # Convert registrations to numeric
        if 'registrations' in df.columns:
            df['registrations'] = pd.to_numeric(df['registrations'], errors='coerce')
            df['registrations'] = df['registrations'].fillna(0)
        
        # Handle date columns
        date_columns = ['month', 'date']
        for date_col in date_columns:
            if date_col in df.columns:
                try:
                    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
                except:
                    continue
        
        # Fill missing categorical data
        categorical_columns = ['state_name', 'rto_name', 'veh_cat', 'maker', 'fuel_type']
        for col in categorical_columns:
            if col in df.columns:
                df[col] = df[col].fillna('Unknown')
        
        return df.dropna(subset=['registrations'])
    
    def _generate_sample_data_structure(self):
        """Generate sample data structure when API is unavailable."""
        # Note: This is only for structure demonstration when real data is unavailable
        st.warning("⚠️ Unable to fetch live VAHAN data. Using sample data structure for demonstration.")
        
        # Generate realistic date range
        start_date = datetime(2019, 1, 1)
        end_date = datetime(2024, 6, 30)
        dates = pd.date_range(start_date, end_date, freq='M')
        
        # Vehicle categories
        vehicle_categories = ['TWO WHEELER', 'THREE WHEELER', 'FOUR WHEELER', 'OTHERS']
        
        # Sample manufacturers
        manufacturers = [
            'Hero MotoCorp', 'Honda', 'TVS', 'Bajaj', 'Suzuki',
            'Maruti Suzuki', 'Hyundai', 'Mahindra', 'Tata Motors',
            'Toyota', 'Ford', 'Volkswagen', 'Skoda', 'Renault'
        ]
        
        # Sample states
        states = [
            'Maharashtra', 'Uttar Pradesh', 'Tamil Nadu', 'Gujarat',
            'Karnataka', 'Rajasthan', 'West Bengal', 'Madhya Pradesh'
        ]
        
        # Generate sample data
        data = []
        for date in dates:
            for state in states:
                for category in vehicle_categories:
                    for manufacturer in np.random.choice(manufacturers, 3):
                        # Generate realistic registration numbers
                        base_registrations = {
                            'TWO WHEELER': np.random.randint(5000, 50000),
                            'FOUR WHEELER': np.random.randint(1000, 10000),
                            'THREE WHEELER': np.random.randint(100, 1000),
                            'OTHERS': np.random.randint(10, 500)
                        }
                        
                        registrations = base_registrations.get(category, 1000)
                        # Add some seasonal variation
                        seasonal_factor = 1 + 0.3 * np.sin(2 * np.pi * date.month / 12)
                        registrations = int(registrations * seasonal_factor)
                        
                        data.append({
                            'month': date,
                            'state_name': state,
                            'state_code': f"ST{states.index(state):02d}",
                            'rto_name': f"{state} RTO",
                            'rto_code': f"RTO{states.index(state):02d}",
                            'veh_cat': category,
                            'maker': manufacturer,
                            'fuel_type': np.random.choice(['PETROL', 'DIESEL', 'ELECTRIC', 'CNG']),
                            'registrations': registrations
                        })
        
        return pd.DataFrame(data)
    
    def process_for_analysis(self, df, date_col):
        """Process data for analysis."""
        # Ensure we have a copy to avoid modifying original
        df = df.copy()
        
        # Group by date and sum registrations
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        df = df.dropna(subset=[date_col])
        
        if df.empty:
            return pd.DataFrame(columns=[date_col, 'registrations'])
            
        analysis_df = df.groupby(date_col)['registrations'].sum().reset_index()
        analysis_df = analysis_df.sort_values(date_col)
        return analysis_df
    
    def calculate_growth_metrics(self, df, date_col):
        """Calculate YoY and QoQ growth metrics."""
        if df.empty or date_col not in df.columns:
            return {
                'yoy_growth': pd.DataFrame(),
                'qoq_growth': pd.DataFrame(),
                'monthly_data': pd.DataFrame()
            }
        
        df = df.copy()
        
        # Ensure date column is properly converted to datetime
        try:
            df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        except Exception:
            return {
                'yoy_growth': pd.DataFrame(),
                'qoq_growth': pd.DataFrame(),
                'monthly_data': pd.DataFrame()
            }
        
        # Drop rows where date conversion failed
        df = df.dropna(subset=[date_col])
        
        if df.empty:
            return {
                'yoy_growth': pd.DataFrame(),
                'qoq_growth': pd.DataFrame(),
                'monthly_data': pd.DataFrame()
            }
        
        df = df.sort_values(date_col)
        
        try:
            # Calculate YoY growth
            df['year'] = df[date_col].dt.year
            df['month'] = df[date_col].dt.month
            
            yearly_data = df.groupby('year')['registrations'].sum().reset_index()
            yearly_data['yoy_growth'] = yearly_data['registrations'].pct_change() * 100
            
            # Calculate QoQ growth
            df['quarter'] = df[date_col].dt.quarter
            df['year_quarter'] = df['year'].astype(str) + '-Q' + df['quarter'].astype(str)
            
            quarterly_data = df.groupby(['year', 'quarter'])['registrations'].sum().reset_index()
            quarterly_data = quarterly_data.sort_values(['year', 'quarter'])
            quarterly_data['qoq_growth'] = quarterly_data['registrations'].pct_change() * 100
            
            return {
                'yoy_growth': yearly_data,
                'qoq_growth': quarterly_data,
                'monthly_data': df
            }
        except Exception as e:
            # If any datetime operations fail, return empty dataframes
            return {
                'yoy_growth': pd.DataFrame(),
                'qoq_growth': pd.DataFrame(),
                'monthly_data': pd.DataFrame()
            }
    
    def analyze_by_category(self, df, date_col):
        """Analyze registrations by vehicle category."""
        if 'veh_cat' not in df.columns:
            return pd.DataFrame()
        
        category_analysis = df.groupby(['veh_cat', pd.Grouper(key=date_col, freq='M')])['registrations'].sum().reset_index()
        category_totals = df.groupby('veh_cat')['registrations'].sum().reset_index()
        
        return {
            'time_series': category_analysis,
            'totals': category_totals
        }
    
    def analyze_by_manufacturer(self, df, date_col):
        """Analyze registrations by manufacturer."""
        if 'maker' not in df.columns:
            return pd.DataFrame()
        
        # Top 10 manufacturers
        top_manufacturers = df.groupby('maker')['registrations'].sum().nlargest(10).index
        df_top = df[df['maker'].isin(top_manufacturers)]
        
        manufacturer_analysis = df_top.groupby(['maker', pd.Grouper(key=date_col, freq='M')])['registrations'].sum().reset_index()
        manufacturer_totals = df_top.groupby('maker')['registrations'].sum().reset_index()
        
        return {
            'time_series': manufacturer_analysis,
            'totals': manufacturer_totals.sort_values('registrations', ascending=False)
        }
    
    def analyze_by_geography(self, df):
        """Analyze registrations by state."""
        if 'state_name' not in df.columns:
            return pd.DataFrame()
        
        geo_analysis = df.groupby('state_name')['registrations'].sum().reset_index()
        geo_analysis = geo_analysis.sort_values('registrations', ascending=False)
        
        return geo_analysis
    
    def generate_investor_insights(self, df, growth_data, date_col):
        """Generate key investor insights from the data."""
        insights = {}
        
        # Market size
        insights['total_market_size'] = df['registrations'].sum()
        
        # Growth trends
        if not growth_data['yoy_growth'].empty:
            latest_yoy = growth_data['yoy_growth'].iloc[-1]['yoy_growth']
            insights['latest_yoy_growth'] = latest_yoy
        
        if not growth_data['qoq_growth'].empty:
            latest_qoq = growth_data['qoq_growth'].iloc[-1]['qoq_growth']
            insights['latest_qoq_growth'] = latest_qoq
        
        # Market leaders
        if 'maker' in df.columns:
            top_manufacturer = df.groupby('maker')['registrations'].sum().idxmax()
            insights['market_leader'] = top_manufacturer
        
        # Category distribution
        if 'veh_cat' in df.columns:
            category_dist = df.groupby('veh_cat')['registrations'].sum()
            insights['dominant_category'] = category_dist.idxmax()
            insights['category_share'] = (category_dist.max() / category_dist.sum()) * 100
        
        # Geographic concentration
        if 'state_name' in df.columns:
            state_dist = df.groupby('state_name')['registrations'].sum()
            insights['top_state'] = state_dist.idxmax()
            insights['state_concentration'] = (state_dist.max() / state_dist.sum()) * 100
        
        return insights
    
    def create_summary_export(self, df, processed_data):
        """Create summary data for export."""
        summary = df.groupby(['state_name', 'veh_cat', 'maker']).agg({
            'registrations': 'sum'
        }).reset_index()
        
        return summary
    
    def create_growth_export(self, growth_data):
        """Create growth analysis data for export."""
        yoy_data = growth_data['yoy_growth'].copy()
        yoy_data['metric_type'] = 'YoY'
        yoy_data = yoy_data.rename(columns={'yoy_growth': 'growth_rate'})
        
        qoq_data = growth_data['qoq_growth'].copy()
        qoq_data['metric_type'] = 'QoQ' 
        qoq_data = qoq_data.rename(columns={'qoq_growth': 'growth_rate'})
        
        combined = pd.concat([
            yoy_data[['year', 'registrations', 'growth_rate', 'metric_type']],
            qoq_data[['year', 'quarter', 'registrations', 'growth_rate', 'metric_type']]
        ], ignore_index=True)
        
        return combined
