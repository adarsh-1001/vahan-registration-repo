# 🚗 VAHAN Vehicle Registration Dashboard

A professional, dark-themed investor dashboard analyzing vehicle registration trends in India using live VAHAN data from the Ministry of Road Transport and Highways. Built for the **Backend Developer Internship Assignment**.

## 🎯 Project Overview

This comprehensive dashboard delivers investor-focused insights into India's automotive market through real-time vehicle registration data analysis. Features modern dark theme UI, responsive design, and interactive visualizations optimized for investment decision-making.

## ✨ Key Features

### 🔴 Live Data Integration
- **Primary Source**: India Data Portal VAHAN dataset (50,000+ records)
- **Fallback System**: Sample CSV data when live data unavailable
- **Auto-refresh**: Manual data refresh capability
- **Error Handling**: Graceful fallback with clear user messaging

### 📈 Advanced Analytics
- **YoY Growth**: Year-over-Year trend analysis with visual indicators
- **QoQ Growth**: Quarter-over-Quarter growth calculations
- **Market Share**: Manufacturer and category market positioning
- **Geographic Analysis**: State-wise distribution and concentration metrics
- **Investor KPIs**: Custom metrics tailored for investment analysis

### 🎨 Professional UI/UX
- **Dark Theme**: Modern investor-friendly color scheme
- **Responsive Design**: Optimized for desktop and mobile devices
- **Interactive Charts**: Plotly-powered hover tooltips and zoom functionality
- **Custom CSS**: Professional styling with gradient cards and animations
- **Modular Components**: Clean, maintainable code architecture

### 🛠️ Technical Excellence
- **Modular Architecture**: Separated concerns with dedicated modules
- **Error Resilience**: Comprehensive error handling and data validation
- **Performance Optimized**: Streamlit caching for fast data loading
- **Export Functionality**: CSV download for filtered datasets

## 📊 Investment Insights

### Vehicle Categories Tracked
- **2W (Two Wheeler)**: Motorcycles, scooters - Mass market indicator
- **3W (Three Wheeler)**: Auto-rickshaws, goods carriers - Commercial segment
- **4W (Four Wheeler)**: Cars, SUVs - Premium market growth
- **Others**: Specialized vehicles - Niche market opportunities

### Key Investment Metrics
- **Market Size**: Total registrations with growth trajectories
- **Market Leaders**: Top manufacturers by volume and growth
- **Geographic Hotspots**: High-growth states and regions
- **Seasonal Patterns**: Monthly/quarterly registration cycles
- **Category Shifts**: Emerging trends in vehicle preferences

## 🏗️ Technical Architecture

### Backend Components
```
app.py                 # Main dashboard orchestration
data_processor.py      # Data fetching and processing logic
dashboard_components.py # Visualization and chart generation
utils.py              # Utility functions and formatters
sample_vahan_data.csv # Fallback data source
```

### Core Technologies
- **Frontend**: Streamlit with custom CSS dark theme
- **Data Processing**: Pandas, NumPy for data manipulation
- **Visualizations**: Plotly Express & Graph Objects
- **Data Source**: REST API integration with fallback CSV
- **Caching**: Streamlit's built-in caching system

### Modular Functions
```python
# Data Processing Pipeline
data_fetch()          # Retrieve data from multiple sources
process_data()        # Clean and standardize data
calculate_growth()    # YoY and QoQ growth metrics

# Visualization Engine
plot_graphs()         # Generate interactive charts
render_dashboard()    # Main UI rendering
render_kpi_cards()    # Investment KPI display
```

## 🚀 Setup Instructions

### For Replit (Recommended)
1. **Fork/Clone Repository**: All files included and configured
2. **Auto-install Dependencies**: Replit handles package management
3. **Run Command**: `streamlit run app.py --server.port 5000`
4. **Access Dashboard**: Via Replit's web preview (port 5000)

### For Local Development
1. **Clone Repository**:
   ```bash
   git clone [repository-url]
   cd vahan-dashboard
   ```

2. **Install Dependencies**:
   ```bash
   pip install streamlit pandas plotly numpy requests trafilatura
   ```

3. **Run Application**:
   ```bash
   streamlit run app.py --server.port 5000
   ```

4. **Open Browser**: `http://localhost:5000`

### Environment Setup
- **Python**: 3.7+ required
- **Internet**: Required for live data fetching
- **Browser**: Modern browser with JavaScript enabled

## 📋 Data Assumptions

### Data Quality
- **Completeness**: Assumes 95%+ data completeness in VAHAN records
- **Timeliness**: Live data typically 1-2 months behind registration date
- **Accuracy**: Government-verified registration data considered authoritative
- **Coverage**: National coverage across all Indian states and RTOs

### Business Assumptions
- **Seasonality**: Vehicle registrations follow festival and monsoon patterns
- **Growth Patterns**: YoY growth reflects economic health and consumer confidence
- **Regional Variations**: State-wise differences due to economic development levels
- **Category Preferences**: Two-wheelers dominate due to affordability and utility

### Technical Assumptions
- **API Availability**: India Data Portal API accessible and stable
- **Data Format**: Consistent JSON/CSV structure from data source
- **Performance**: Dashboard responsive with datasets up to 100,000 records
- **Browser Compatibility**: Modern browser support for Plotly visualizations

## 🔮 Future Roadmap

### Phase 1: Enhanced Analytics (Next 2 months)
- [ ] **Predictive Modeling**: ML models for registration forecasting
- [ ] **Sentiment Analysis**: News/social media impact on vehicle sales
- [ ] **Economic Correlation**: GDP, fuel price correlation analysis
- [ ] **Regional Deep-dive**: District-level granular analysis

### Phase 2: Advanced Features (3-6 months)
- [ ] **Real-time Alerts**: Email notifications for significant market changes
- [ ] **Comparative Analysis**: Peer benchmarking for manufacturers
- [ ] **Export Enhancements**: PDF reports, PowerPoint export
- [ ] **API Development**: REST API for programmatic access

### Phase 3: Enterprise Features (6-12 months)
- [ ] **Multi-user Support**: Role-based access control
- [ ] **Database Integration**: PostgreSQL for data persistence
- [ ] **Advanced Visualizations**: 3D charts, geographic heat maps
- [ ] **Mobile App**: Native iOS/Android companion app

### Technical Enhancements
- [ ] **Performance**: Database caching for sub-second load times
- [ ] **Scalability**: Support for millions of records
- [ ] **Security**: OAuth authentication, data encryption
- [ ] **Monitoring**: Application performance monitoring and logging

## 🎥 Demo & Presentation

### Key Demo Points
1. **Live Data Loading**: Show real-time data fetch from VAHAN
2. **Interactive Filtering**: Demonstrate date range and category filters
3. **Growth Analysis**: Highlight YoY/QoQ trends with visual indicators
4. **Investment Insights**: Walk through investor-specific KPIs
5. **Export Functionality**: Download filtered datasets for analysis

### Investor Insights to Highlight
- **Market Expansion**: Two-wheeler segment growth in rural areas
- **EV Transition**: Electric vehicle registration trends
- **Regional Opportunities**: High-growth states for market entry
- **Seasonal Patterns**: Optimal timing for product launches
- **Competitive Landscape**: Market share dynamics and leadership changes

## 📊 Data Sources & APIs

### Primary Data
- **Source**: India Data Portal - Ministry of Road Transport & Highways
- **API**: `https://ckandev.indiadataportal.com/api/action/datastore_search`
- **Resource ID**: `808d2b3c-dcdd-48fc-ae6a-cc99e137ec9c`
- **Update Frequency**: Monthly
- **Coverage**: 2019-2024, All Indian states

### Fallback Data
- **File**: `sample_vahan_data.csv`
- **Records**: 35 sample records across multiple states/categories
- **Purpose**: Demonstration when live API unavailable
- **Structure**: Mirrors live data format exactly

## 🔧 Configuration Files

### Streamlit Configuration (`.streamlit/config.toml`)
```toml
[server]
headless = true
address = "0.0.0.0"
port = 5000

[theme]
base = "dark"
primaryColor = "#00ff88"
backgroundColor = "#0e1117"
secondaryBackgroundColor = "#262730"
textColor = "#ffffff"
```

## 📈 Investment Thesis

### Market Opportunity
The Indian automotive market represents a $118+ billion opportunity with vehicle registrations serving as a leading indicator of economic growth, consumer confidence, and sector health. This dashboard provides institutional-grade analysis tools for:

- **OEMs**: Production planning and market share monitoring
- **Financial Institutions**: Credit portfolio risk assessment
- **Investors**: Sector allocation and timing decisions
- **Government**: Policy impact measurement and planning

### Competitive Advantage
- **Real-time Data**: Unlike quarterly reports, provides monthly insights
- **Comprehensive Coverage**: National scope across all vehicle categories
- **Professional Interface**: Investment-grade presentation and analysis
- **Export Ready**: Seamless integration into investment workflows

---

**Built for Backend Developer Internship Assignment**  
**Data Source**: VAHAN Dashboard - Ministry of Road Transport and Highways, Government of India  
**Technology Stack**: Python, Streamlit, Plotly, Pandas  
**Theme**: Professional Dark Theme for Investor Focus
